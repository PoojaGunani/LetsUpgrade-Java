class Employee
{
  public String name;
  public String city;
  public int age;
  
  public void display() {
  System.out.println("Name is : "+name);
  System.out.println("City is : "+city);
  System.out.println("Age is : "+age);
 }

  public static void main(String[] args)
  {
   Employee e = new Employee();
   e.name="Pooja";
   e.city="Pune";
   e.age=20;
 
  Employee e1 = new Employee();
  e1.name="Saurab";
  e1.city="Chennai";
  e1.age=23;

  System.out.println(" Employee Details ");
  e.display();
  e1.display();
  }

}